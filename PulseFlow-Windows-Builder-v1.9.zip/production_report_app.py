#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""PulseFlow：科技感生產報告桌面應用程式。"""
from __future__ import annotations

import json
import os
import queue
import tempfile
import threading
import traceback
import zipfile
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import build_226926131000_report as report

DEFAULT_REPORT_NAME = '2D AFVI 批次量產分析報告'
DEFAULT_AI_PATTERN = 'AI.csv'
ROOT_TOKEN = report.ROOT_TOKEN
ROOT_LABEL = '（此資料夾本身的檔案）'


def _settings_file():
    base = os.environ.get('APPDATA') or str(Path.home())
    return Path(base) / 'PulseFlow' / 'settings.json'


def load_settings():
    try:
        return json.loads(_settings_file().read_text(encoding='utf-8'))
    except Exception:
        return {}


def save_setting(key, value):
    """記住某個按鈕最後一次選的資料夾（來源 / 輸出 / AI 各自獨立）。"""
    try:
        data = load_settings()
        data[key] = value if (value is None or isinstance(value, list)) else str(value)
        f = _settings_file()
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    except Exception:
        pass


NAVY = '#071426'
PANEL = '#0D2038'
PANEL_2 = '#102B47'
CYAN = '#23D6D5'
CYAN_DARK = '#0E8E9B'
TEXT = '#EAF8FF'
MUTED = '#8EA9BC'
BORDER = '#1C4665'
GREEN = '#63E6BE'
RED = '#FF7186'


class ReportApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('PulseFlow')
        self.geometry(f'1000x{min(840, max(660, self.winfo_screenheight() - 90))}')
        self.minsize(880, 640)
        self.configure(bg=NAVY)
        self.input_dir = tk.StringVar()
        self.output_dir = tk.StringVar()
        self.ai_dir = tk.StringVar()
        self.ai_pattern = tk.StringVar(value=DEFAULT_AI_PATTERN)
        self.ai_recursive = tk.BooleanVar(value=True)
        self.out_pdf = tk.BooleanVar(value=True)
        self.out_xlsx = tk.BooleanVar(value=True)
        self.out_png = tk.BooleanVar(value=True)
        self.report_name = tk.StringVar(value=DEFAULT_REPORT_NAME)
        self.settings = load_settings()
        for key, var in (('input_dir', self.input_dir), ('output_dir', self.output_dir), ('ai_dir', self.ai_dir)):
            last = self.settings.get(key, '')
            if last and Path(last).is_dir():
                var.set(last)
        # 各資料夾內「勾選的子資料夾」：None 代表全部；*_root 記錄這份勾選是針對哪個資料夾
        self.sel = {'input': None, 'ai': None}
        self.sel_root = {'input': '', 'ai': ''}
        self.sel_total = {'input': 0, 'ai': 0}
        for kind, dir_key, var in (('input', 'input_dir', self.input_dir), ('ai', 'ai_dir', self.ai_dir)):
            saved = self.settings.get(kind + '_sel')
            if isinstance(saved, list) and var.get() and var.get() == self.settings.get(dir_key):
                self.sel[kind] = [n for n in saved if n == ROOT_TOKEN or (Path(var.get()) / n).is_dir()] or None
                self.sel_root[kind] = var.get()
                self.sel_total[kind] = int(self.settings.get(kind + '_total', 0) or 0)
        self.status = tk.StringVar(value='準備就緒｜請選擇含 CSV 的資料夾（含子資料夾）')
        self.progress_value = tk.DoubleVar(value=0)
        self.messages = queue.Queue()
        self.running = False
        self._setup_style()
        self._load_icon()
        self._build_ui()
        self.after(100, self._drain_messages)

    def _setup_style(self):
        style = ttk.Style(self)
        try:
            style.theme_use('clam')
        except tk.TclError:
            pass
        style.configure('Tech.TFrame', background=NAVY)
        style.configure('Card.TFrame', background=PANEL)
        style.configure('Title.TLabel', background=NAVY, foreground=TEXT,
                        font=('Microsoft JhengHei UI', 24, 'bold'))
        style.configure('Subtitle.TLabel', background=NAVY, foreground=MUTED,
                        font=('Microsoft JhengHei UI', 10))
        style.configure('CardTitle.TLabel', background=PANEL, foreground=TEXT,
                        font=('Microsoft JhengHei UI', 11, 'bold'))
        style.configure('CardText.TLabel', background=PANEL, foreground=MUTED,
                        font=('Microsoft JhengHei UI', 9))
        style.configure('Field.TLabel', background=PANEL, foreground=MUTED,
                        font=('Microsoft JhengHei UI', 9))
        style.configure('Tech.TEntry', fieldbackground='#091A2E', foreground=TEXT,
                        bordercolor=BORDER, lightcolor=BORDER, darkcolor=BORDER,
                        insertcolor=CYAN, padding=8)
        style.configure('Accent.TButton', background=CYAN_DARK, foreground=TEXT,
                        bordercolor=CYAN, lightcolor=CYAN_DARK, darkcolor=CYAN_DARK,
                        font=('Microsoft JhengHei UI', 10, 'bold'), padding=(16, 9))
        style.map('Accent.TButton', background=[('active', '#16B8C0'), ('disabled', '#24445A')])
        style.configure('Ghost.TButton', background=PANEL_2, foreground=TEXT,
                        bordercolor=BORDER, lightcolor=PANEL_2, darkcolor=PANEL_2,
                        font=('Microsoft JhengHei UI', 9), padding=(12, 8))
        style.map('Ghost.TButton', background=[('active', '#1A4262')])
        style.configure('Tech.Horizontal.TProgressbar', troughcolor='#091A2E',
                        background=CYAN, bordercolor=BORDER, lightcolor=CYAN,
                        darkcolor=CYAN, thickness=8)
        style.configure('Status.TLabel', background=NAVY, foreground=MUTED,
                        font=('Microsoft JhengHei UI', 9))

    def _load_icon(self):
        try:
            root = Path(getattr(__import__('sys'), '_MEIPASS', Path(__file__).parent))
            ico = root / 'app_icon.ico'
            if ico.exists():
                self.iconbitmap(str(ico))
            png = root / 'app_icon.png'
            if png.exists():
                self._icon_image = tk.PhotoImage(file=str(png))
                self.iconphoto(True, self._icon_image)
        except Exception:
            pass

    def _build_ui(self):
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        outer = ttk.Frame(self, style='Tech.TFrame', padding=(28, 22, 28, 18))
        outer.grid(row=0, column=0, rowspan=5, sticky='nsew')
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(2, weight=1)

        header = ttk.Frame(outer, style='Tech.TFrame')
        header.grid(row=0, column=0, sticky='ew', pady=(0, 20))
        header.columnconfigure(1, weight=1)
        logo = tk.Canvas(header, width=58, height=58, bg=NAVY, highlightthickness=0)
        logo.grid(row=0, column=0, rowspan=2, padx=(0, 15))
        logo.create_oval(5, 5, 53, 53, fill='#0D314C', outline=CYAN, width=2)
        logo.create_line(14, 31, 21, 31, 24, 26, 28, 37, 33, 18, 37, 34, 40, 31, 44, 31, fill=CYAN,
                         width=3, capstyle='round', joinstyle='round')
        logo.create_oval(42, 29, 46, 33, fill='#63E6BE', outline='')
        ttk.Label(header, text='PulseFlow', style='Title.TLabel').grid(row=0, column=1, sticky='w')
        ttk.Label(header, text='PRODUCTION REPORT  /  CSV + AI 缺陷檔 → PDF + XLSX + PNG', style='Subtitle.TLabel').grid(row=1, column=1, sticky='w', pady=(3, 0))
        ttk.Label(header, text='v1.9', style='Subtitle.TLabel').grid(row=0, column=2, sticky='ne')

        steps = ttk.Frame(outer, style='Tech.TFrame')
        steps.grid(row=1, column=0, sticky='ew', pady=(0, 14))
        for i, (num, label, desc) in enumerate([('01', '資料來源', 'CSV 資料夾（含子資料夾）＋AI 缺陷檔'), ('02', '輸出設定', '指定報告位置與檔案'), ('03', '產生報告', '選擇 PDF / Excel / PNG')]):
            steps.columnconfigure(i, weight=1)
            card = ttk.Frame(steps, style='Card.TFrame', padding=(13, 11))
            card.grid(row=0, column=i, sticky='ew', padx=(0 if i == 0 else 6, 6 if i < 2 else 0))
            tk.Label(card, text=num, bg=PANEL, fg=CYAN, font=('Consolas', 16, 'bold')).grid(row=0, column=0, rowspan=2, padx=(0, 10))
            ttk.Label(card, text=label, style='CardTitle.TLabel').grid(row=0, column=1, sticky='w')
            ttk.Label(card, text=desc, style='CardText.TLabel').grid(row=1, column=1, sticky='w', pady=(2, 0))

        body = ttk.Frame(outer, style='Tech.TFrame')
        body.grid(row=2, column=0, sticky='nsew')
        body.columnconfigure(0, weight=3)
        body.columnconfigure(1, weight=2)
        body.rowconfigure(0, weight=1)

        form = ttk.Frame(body, style='Card.TFrame', padding=(20, 18))
        form.grid(row=0, column=0, sticky='nsew', padx=(0, 8))
        form.columnconfigure(1, weight=1)
        ttk.Label(form, text='報告來源與輸出設定', style='CardTitle.TLabel').grid(row=0, column=0, columnspan=3, sticky='w', pady=(0, 15))
        self._field(form, 1, 'CSV 資料夾', self.input_dir, '選擇來源', self.choose_input)
        self.src_hint = ttk.Label(form, text='自動搜尋所有子資料夾內的 CSV，檔名含 result 的檔案會排除。',
                                  style='CardText.TLabel', wraplength=300, justify='left')
        self.src_hint.grid(row=2, column=1, columnspan=2, sticky='w', padx=10, pady=(0, 2))
        self._field(form, 3, '輸出資料夾', self.output_dir, '選擇位置', self.choose_output)
        ttk.Separator(form).grid(row=5, column=0, columnspan=3, sticky='ew', pady=(8, 10))
        ttk.Label(form, text='AI 缺陷檔匯入（選填｜缺陷位置/類型）', style='CardTitle.TLabel').grid(row=6, column=0, columnspan=3, sticky='w', pady=(0, 2))
        self._field(form, 7, 'AI 檔資料夾', self.ai_dir, '選擇路徑', self.choose_ai)
        ttk.Label(form, text='檔名樣式', style='Field.TLabel').grid(row=8, column=0, sticky='w', pady=7)
        ttk.Entry(form, textvariable=self.ai_pattern, style='Tech.TEntry').grid(row=8, column=1, sticky='ew', padx=10, pady=7)
        self._toggle(form, '含子資料夾', self.ai_recursive).grid(row=8, column=2, sticky='ew', pady=7)
        self.ai_hint = ttk.Label(form, text='預設 AI.csv，可自行修改；可用 * ? ，多組以 ; 分隔，例如  AI*.csv;*.ai。Step_Code 後 4 碼 = Strip ID，用來與主報表比對。',
                                 style='CardText.TLabel', wraplength=480, justify='left')
        self.ai_hint.grid(row=9, column=0, columnspan=3, sticky='w')
        self.src_hint.bind('<Button-1>', lambda e: self._edit_sel('input'))
        self.ai_hint.bind('<Button-1>', lambda e: self._edit_sel('ai'))
        self.input_dir.trace_add('write', self._refresh_hints)
        self.ai_dir.trace_add('write', self._refresh_hints)
        self._refresh_hints()
        form.bind('<Configure>', lambda e: (self.ai_hint.configure(wraplength=max(260, e.width - 50)),
                                            self.src_hint.configure(wraplength=max(200, e.width - 190))))
        ttk.Separator(form).grid(row=10, column=0, columnspan=3, sticky='ew', pady=(10, 10))
        ttk.Label(form, text='輸出內容（可複選）', style='CardTitle.TLabel').grid(row=11, column=0, columnspan=3, sticky='w', pady=(0, 8))
        outputs = ttk.Frame(form, style='Card.TFrame')
        outputs.grid(row=12, column=0, columnspan=3, sticky='ew')
        for i, (tag, name, color, var) in enumerate([('PDF', '生產報告', '#FFB86B', self.out_pdf),
                                                     ('XLSX', '明細與統計', '#63E6BE', self.out_xlsx),
                                                     ('PNG', '缺點分布圖', '#7AA7FF', self.out_png)]):
            outputs.columnconfigure(i, weight=1, uniform='out')
            self._toggle(outputs, f'{tag}\n{name}', var, color).grid(row=0, column=i, sticky='ew', padx=(0 if i == 0 else 5, 0 if i == 2 else 5))
        ttk.Label(form, text='報告名稱', style='Field.TLabel').grid(row=13, column=0, sticky='w', pady=(14, 7))
        ttk.Entry(form, textvariable=self.report_name, style='Tech.TEntry').grid(row=13, column=1, sticky='ew', padx=10, pady=(14, 7))
        ttk.Label(form, text='檔名與報告標題', style='CardText.TLabel').grid(row=13, column=2, sticky='w', pady=(14, 0))

        activity = ttk.Frame(body, style='Card.TFrame', padding=(18, 18))
        activity.grid(row=0, column=1, sticky='nsew', padx=(8, 0))
        activity.columnconfigure(0, weight=1)
        activity.rowconfigure(2, weight=1)
        ttk.Label(activity, text='處理狀態', style='CardTitle.TLabel').grid(row=0, column=0, sticky='w')
        self.status_badge = tk.Label(activity, text=' READY ', bg='#123753', fg=CYAN, font=('Consolas', 9, 'bold'), padx=8, pady=4)
        self.status_badge.grid(row=0, column=1, sticky='e')
        self.progress = ttk.Progressbar(activity, variable=self.progress_value, maximum=100, style='Tech.Horizontal.TProgressbar')
        self.progress.grid(row=1, column=0, columnspan=2, sticky='ew', pady=(16, 12))
        self.log = tk.Text(activity, state='disabled', wrap='word', bg='#08182A', fg='#B9D7E6', insertbackground=CYAN,
                           relief='flat', borderwidth=0, padx=12, pady=12, font=('Consolas', 9), height=12)
        self.log.grid(row=2, column=0, columnspan=2, sticky='nsew')
        scroll = ttk.Scrollbar(activity, orient='vertical', command=self.log.yview)
        scroll.grid(row=2, column=2, sticky='ns')
        self.log.configure(yscrollcommand=scroll.set)

        footer = ttk.Frame(outer, style='Tech.TFrame')
        footer.grid(row=3, column=0, sticky='ew', pady=(18, 0))
        footer.columnconfigure(0, weight=1)
        ttk.Label(footer, textvariable=self.status, style='Status.TLabel').grid(row=0, column=0, sticky='w')
        self.generate_btn = ttk.Button(footer, text='▶ 產生報告', style='Accent.TButton', command=self.generate)
        self.generate_btn.grid(row=0, column=1, padx=(12, 8))
        ttk.Button(footer, text='關閉', style='Ghost.TButton', command=self.destroy).grid(row=0, column=2)

    def _field(self, parent, row, label, variable, button_text, command):
        ttk.Label(parent, text=label, style='Field.TLabel').grid(row=row, column=0, sticky='w', pady=7)
        ttk.Entry(parent, textvariable=variable, style='Tech.TEntry').grid(row=row, column=1, sticky='ew', padx=10, pady=7)
        ttk.Button(parent, text=button_text, style='Ghost.TButton', command=command).grid(row=row, column=2, sticky='ew', pady=7)

    def _toggle(self, parent, text, variable, color=None):
        """與 Ghost 按鈕同風格的開關鈕；勾選時以 ✔ 與強調色表示。"""
        on_bg = color or CYAN_DARK
        on_fg = NAVY if color else TEXT
        btn = tk.Checkbutton(parent, text=text, variable=variable, indicatoron=False,
                             bg=PANEL_2, fg=TEXT, selectcolor=on_bg, activebackground='#1A4262',
                             activeforeground=TEXT, relief='flat', bd=0, highlightthickness=1,
                             highlightbackground=BORDER, highlightcolor=CYAN, cursor='hand2',
                             font=('Microsoft JhengHei UI', 9), padx=6, pady=6, justify='center')

        def refresh(*_):
            on = bool(variable.get())
            btn.configure(text=(('✔ ' if on else '　 ') + text) if '\n' not in text else (('✔ ' if on else '') + text), fg=on_fg if on else TEXT,
                          activebackground=on_bg if on else '#1A4262',
                          activeforeground=on_fg if on else TEXT)
        variable.trace_add('write', refresh)
        refresh()
        return btn

    def _start_dir(self, key, var):
        """對話框的起始位置：欄位目前的資料夾 → 該按鈕上次選的資料夾 → 預設。"""
        for cand in (var.get().strip(), self.settings.get(key, '')):
            if cand and Path(cand).is_dir():
                return cand
        return None

    def choose_input(self):
        path = filedialog.askdirectory(title='選擇含 CSV 檔案的資料夾', initialdir=self._start_dir('input_dir', self.input_dir))
        if not path:
            return
        if not self._ask_subfolders('input', path, '選擇來源：勾選要處理的子資料夾'):
            return
        self.input_dir.set(path)
        save_setting('input_dir', path)
        if not self.output_dir.get():
            self.output_dir.set(str(Path(path) / '報告輸出'))
        self._log(f'[SOURCE] {path}' + self._sel_text('input'))
        self.status.set('已選擇來源｜請確認輸出資料夾後產生報告')

    def choose_output(self):
        path = filedialog.askdirectory(title='選擇報告輸出資料夾', initialdir=self._start_dir('output_dir', self.output_dir))
        if path:
            self.output_dir.set(path)
            save_setting('output_dir', path)
            self._log(f'[OUTPUT] {path}')

    def choose_ai(self):
        path = filedialog.askdirectory(title='選擇 AI 缺陷檔所在資料夾', initialdir=self._start_dir('ai_dir', self.ai_dir))
        if not path:
            return
        if not self._ask_subfolders('ai', path, '選擇路徑：勾選要處理的 AI 子資料夾'):
            return
        self.ai_dir.set(path)
        save_setting('ai_dir', path)
        self._log(f'[AI] {path}' + self._sel_text('ai'))

    # ---------- 子資料夾勾選 ----------
    def _sel_for(self, kind):
        """目前有效的勾選清單（欄位路徑與勾選當時的資料夾相同才有效；None＝全部）。"""
        var = self.input_dir if kind == 'input' else self.ai_dir
        cur = var.get().strip()
        if self.sel[kind] is not None and cur and cur == self.sel_root[kind]:
            return self.sel[kind]
        return None

    def _sel_text(self, kind):
        sel = self._sel_for(kind)
        if sel is None:
            return ''
        n = len([x for x in sel if x != ROOT_TOKEN])
        total = self.sel_total[kind]
        extra = '＋資料夾本身的檔案' if ROOT_TOKEN in sel else ''
        return f'｜已勾選 {n}' + (f' / {total}' if total else '') + f' 個子資料夾{extra}'

    def _refresh_hints(self, *_):
        try:
            txt = self._sel_text('input')
            base = '自動搜尋所有子資料夾內的 CSV，檔名含 result 的檔案會排除。'
            self.src_hint.configure(text=(('已' + txt[2:] + '（點此重新勾選）') if txt else base),
                                    cursor='hand2' if txt else '')
            txt = self._sel_text('ai')
            base = ('預設 AI.csv，可自行修改；可用 * ? ，多組以 ; 分隔，例如  AI*.csv;*.ai。'
                    'Step_Code 後 4 碼 = Strip ID，用來與主報表比對。')
            self.ai_hint.configure(text=((('已' + txt[2:] + '（點此重新勾選）\n') if txt else '') + base),
                                   cursor='hand2' if txt else '')
        except Exception:
            pass

    def _edit_sel(self, kind):
        """點提示文字：對目前資料夾重新勾選。"""
        if self._sel_for(kind) is None:
            return
        var = self.input_dir if kind == 'input' else self.ai_dir
        title = '選擇來源：勾選要處理的子資料夾' if kind == 'input' else '選擇路徑：勾選要處理的 AI 子資料夾'
        self._ask_subfolders(kind, var.get().strip(), title)

    def _ask_subfolders(self, kind, root, title):
        """選好資料夾後，跳出勾選視窗：確認要處理該資料夾內的哪些子資料夾。
        回傳 False 代表使用者取消；沒有子資料夾時直接視為全部。"""
        try:
            subs = sorted([p.name for p in Path(root).iterdir() if p.is_dir()], key=report._natural_key)
        except OSError:
            subs = []
        if not subs:
            self.sel[kind], self.sel_root[kind], self.sel_total[kind] = None, root, 0
            self._save_sel(kind, root)
            self._refresh_hints()
            return True
        current = self.sel[kind] if self.sel_root[kind] == root else None
        try:
            result = self._subfolder_dialog(title, root, subs, current)
        except Exception as exc:                      # 視窗失敗時不要擋住流程：視為全部
            self._log(f'[WARN] 勾選視窗開啟失敗，改為處理全部子資料夾：{exc}')
            result = (True, None)
        ok, chosen = result
        if not ok:
            return False
        self.sel[kind], self.sel_root[kind], self.sel_total[kind] = chosen, root, len(subs)
        self._save_sel(kind, root)
        self._refresh_hints()
        return True

    def _save_sel(self, kind, root):
        save_setting(kind + '_sel', self.sel[kind])
        save_setting(kind + '_total', self.sel_total[kind])
        self.settings[kind + '_sel'] = self.sel[kind]

    def _subfolder_dialog(self, title, root, subs, current):
        items = [ROOT_TOKEN] + subs
        labels = {ROOT_TOKEN: ROOT_LABEL}
        chosen0 = set(items) if current is None else set(current)
        win = tk.Toplevel(self)
        win.title(title)
        win.configure(bg=PANEL)
        win.transient(self)
        win.geometry(f'520x560+{self.winfo_rootx() + 60}+{self.winfo_rooty() + 40}')
        win.minsize(420, 420)
        result = {'ok': False, 'chosen': None}
        vars_ = {n: tk.BooleanVar(value=(n in chosen0)) for n in items}
        flt = tk.StringVar()
        count = tk.StringVar()

        tk.Label(win, text=str(root), bg=PANEL, fg=MUTED, anchor='w', justify='left', wraplength=480,
                 font=('Microsoft JhengHei UI', 9)).pack(fill='x', padx=16, pady=(14, 2))
        tk.Label(win, text='勾選要處理的子資料夾（每個勾選的資料夾會連同其內層一起搜尋）', bg=PANEL, fg=TEXT, anchor='w',
                 font=('Microsoft JhengHei UI', 10, 'bold')).pack(fill='x', padx=16, pady=(0, 8))

        top = tk.Frame(win, bg=PANEL)
        top.pack(fill='x', padx=16)
        tk.Label(top, text='篩選', bg=PANEL, fg=MUTED, font=('Microsoft JhengHei UI', 9)).pack(side='left')
        ent = tk.Entry(top, textvariable=flt, bg=NAVY, fg=TEXT, insertbackground=TEXT, relief='flat',
                       highlightthickness=1, highlightbackground=BORDER, highlightcolor=CYAN,
                       font=('Microsoft JhengHei UI', 10))
        ent.pack(side='left', fill='x', expand=True, padx=8, ipady=4)

        mid = tk.Frame(win, bg=PANEL)
        mid.pack(fill='both', expand=True, padx=16, pady=8)
        canvas = tk.Canvas(mid, bg=PANEL_2, highlightthickness=0)
        sb = ttk.Scrollbar(mid, orient='vertical', command=canvas.yview)
        inner = tk.Frame(canvas, bg=PANEL_2)
        inner_id = canvas.create_window((0, 0), window=inner, anchor='nw')
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side='left', fill='both', expand=True)
        sb.pack(side='right', fill='y')
        inner.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>', lambda e: canvas.itemconfigure(inner_id, width=e.width))

        rows = {}
        for n in items:
            btn = self._toggle(inner, labels.get(n, n), vars_[n])
            btn.configure(anchor='w', padx=12, pady=5)
            btn.grid(sticky='ew', padx=4, pady=1)
            rows[n] = btn
        inner.columnconfigure(0, weight=1)

        def visible():
            key = flt.get().strip().lower()
            return [n for n in items if not key or key in labels.get(n, n).lower()]

        def refresh(*_):
            vis = set(visible())
            for n, w in rows.items():
                if n in vis:
                    w.grid()
                else:
                    w.grid_remove()
            picked = sum(1 for n in items if vars_[n].get())
            count.set(f'已勾選 {picked} / {len(items)}（含「資料夾本身」）')
            canvas.yview_moveto(0)

        def set_visible(fn):
            for n in visible():
                vars_[n].set(fn(vars_[n].get()))
            count.set(f'已勾選 {sum(1 for n in items if vars_[n].get())} / {len(items)}（含「資料夾本身」）')

        for v in vars_.values():
            v.trace_add('write', lambda *_: count.set(
                f'已勾選 {sum(1 for n in items if vars_[n].get())} / {len(items)}（含「資料夾本身」）'))
        flt.trace_add('write', refresh)

        def wheel(e):
            canvas.yview_scroll(int(-e.delta / 120), 'units')
        win.bind('<MouseWheel>', wheel)

        tools = tk.Frame(win, bg=PANEL)
        tools.pack(fill='x', padx=16)
        for text, fn in (('全選', lambda: set_visible(lambda v: True)), ('全不選', lambda: set_visible(lambda v: False)),
                         ('反選', lambda: set_visible(lambda v: not v))):
            ttk.Button(tools, text=text, style='Ghost.TButton', command=fn).pack(side='left', padx=(0, 8))
        tk.Label(tools, textvariable=count, bg=PANEL, fg=MUTED, font=('Microsoft JhengHei UI', 9)).pack(side='right')

        def accept():
            picked = [n for n in items if vars_[n].get()]
            if not picked:
                messagebox.showwarning('未勾選', '請至少勾選一個項目。', parent=win)
                return
            result['ok'] = True
            result['chosen'] = None if len(picked) == len(items) else picked
            win.destroy()

        bottom = tk.Frame(win, bg=PANEL)
        bottom.pack(fill='x', padx=16, pady=(10, 14))
        ttk.Button(bottom, text='確定', style='Accent.TButton', command=accept).pack(side='right')
        ttk.Button(bottom, text='取消', style='Ghost.TButton', command=win.destroy).pack(side='right', padx=(0, 8))

        refresh()
        try:
            win.wait_visibility()
            win.grab_set()
        except Exception:
            pass
        ent.focus_set()
        self.wait_window(win)
        return result['ok'], result['chosen']

    def _log(self, text):
        self.log.configure(state='normal')
        self.log.insert('end', text + '\n')
        self.log.see('end')
        self.log.configure(state='disabled')

    def _drain_messages(self):
        try:
            while True:
                kind, payload = self.messages.get_nowait()
                if kind == 'log': self._log(payload)
                elif kind == 'progress': self.progress_value.set(payload)
                elif kind == 'done':
                    self.running = False
                    self.generate_btn.configure(state='normal')
                    self.status_badge.configure(text=' DONE ', bg='#164D48', fg=GREEN)
                    self.status.set('完成｜' + payload.split(' 輸出完成')[0] + ' 已輸出')
                    self.progress_value.set(100)
                    self._log(payload)
                    messagebox.showinfo('產生完成', payload)
                elif kind == 'error':
                    self.running = False
                    self.generate_btn.configure(state='normal')
                    self.status_badge.configure(text=' ERROR ', bg='#5A2332', fg=RED)
                    self.status.set('產生失敗｜請查看處理狀態')
                    self._log(payload)
                    messagebox.showerror('產生失敗', payload)
        finally:
            self.after(100, self._drain_messages)

    def generate(self):
        if self.running: return
        input_dir = Path(self.input_dir.get().strip())
        output_dir = Path(self.output_dir.get().strip())
        stem = self.report_name.get().strip() or DEFAULT_REPORT_NAME
        if not input_dir.is_dir():
            messagebox.showwarning('資料夾未選擇', '請先選擇有效的 CSV 資料夾。'); return
        csv_files, excluded = report.find_summary_csvs(input_dir, self._sel_for('input'))
        if not csv_files:
            messagebox.showwarning('找不到 CSV', '指定資料夾（含子資料夾）內沒有可用的 .csv 檔案（檔名含 result 的檔案已排除）。'); return
        outputs = [k for k, v in (('pdf', self.out_pdf), ('xlsx', self.out_xlsx), ('png', self.out_png)) if v.get()]
        if not outputs:
            messagebox.showwarning('未選擇輸出', '請至少勾選一種輸出內容（PDF / XLSX / PNG）。'); return
        if any(ch in stem for ch in '/\\:*?"<>|'):
            messagebox.showwarning('檔名不合法', '報告檔名前綴不可包含 \\ / : * ? " < > |'); return
        ai_dir = self.ai_dir.get().strip()
        ai_files = []
        if ai_dir:
            if not Path(ai_dir).is_dir():
                messagebox.showwarning('AI 資料夾無效', '請選擇有效的 AI 檔資料夾，或清空此欄位略過缺陷類型。'); return
            ai_files = report.find_ai_files(ai_dir, self.ai_pattern.get(), self.ai_recursive.get(), self._sel_for('ai'))
            if not ai_files:
                messagebox.showwarning('找不到 AI 檔', f'在 AI 資料夾找不到符合「{self.ai_pattern.get()}」的檔案。'); return
        output_dir.mkdir(parents=True, exist_ok=True)
        save_setting('input_dir', input_dir)
        save_setting('output_dir', output_dir)
        if ai_dir:
            save_setting('ai_dir', ai_dir)
        self.running = True
        self.generate_btn.configure(state='disabled')
        self.status_badge.configure(text=' RUNNING ', bg='#164B60', fg=CYAN)
        self.progress_value.set(5)
        self.status.set('處理中｜正在解析 CSV 並產生報告')
        self._log(f'[SCAN] 找到 {len(csv_files)} 個 CSV（含子資料夾），已排除 {excluded} 個檔名含 result 的檔案{self._sel_text("input")}')
        if ai_files:
            self._log(f'[AI] 找到 {len(ai_files)} 個 AI 檔{self._sel_text("ai")}')
        threading.Thread(target=self._worker, args=(csv_files, output_dir, stem, ai_files, outputs, input_dir), daemon=True).start()

    def _worker(self, csv_files, output_dir, stem, ai_files=(), outputs=('pdf', 'xlsx', 'png'), input_dir=None):
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(prefix='production_report_', suffix='.zip', delete=False) as tmp:
                temp_path = Path(tmp.name)
            with zipfile.ZipFile(temp_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
                for i, csv_path in enumerate(csv_files, 1):
                    rel = csv_path.relative_to(input_dir).as_posix() if input_dir else csv_path.name
                    zf.write(csv_path, arcname=rel)
                    self.messages.put(('progress', 5 + i / len(csv_files) * 20))
                    self.messages.put(('log', f'[READ] {rel}'))
            report.configure_paths(temp_path, output_dir, stem)
            batches, observations = report.parse_archive()
            self.messages.put(('log', f'[PARSE] {len(batches)} 批次 / {len(observations)} 筆紀錄'))
            if report.SKIPPED_FILES:
                self.messages.put(('log', f'[SKIP] {len(report.SKIPPED_FILES)} 個非檢驗摘要 CSV 已略過'))
            stats = report.build_views(batches, observations)
            if stats['unreadable_strips']:
                self.messages.put(('log', f'[WARN] 2D Code 讀取失敗（FAILED）{stats["unreadable_strips"]} 條，已視為獨立的條、不參與 AI 比對'))
            if ai_files:
                ai = report.parse_ai_files(ai_files)
                report.build_ai_stats(stats, ai)
                a = stats['ai']
                self.messages.put(('log', f'[AI] 讀入 {a["file_count"]} 檔 / {a["defect_total"]:,} 筆缺陷；'
                                          f'比對成功 {a["matched_strips"]} 條，主報表無 AI {a["summary_strips_without_ai"]} 條，'
                                          f'AI 無對應 {a["ai_ids_not_in_summary"]} 條'))
                for name, why in a['bad_files'][:5]:
                    self.messages.put(('log', f'[AI-WARN] {name}：{why}'))
                self.messages.put(('log', f'[AI] 最主要缺陷：{a["top_label"]}（{a["top_count"]:,} 筆，{a["top_pct"]:.1%}）'))
            self.messages.put(('progress', 55))
            produced = report.generate_outputs(stats, outputs, lambda v: self.messages.put(('progress', v)))
            names = {'pdf': 'PDF', 'xlsx': 'Excel', 'png': 'PNG'}
            label = '、'.join(names[k] for k in ('pdf', 'xlsx', 'png') if k in outputs)
            self.messages.put(('done', f'{label} 輸出完成：\n' + '\n'.join(str(path) for path in produced)))
        except Exception as exc:
            details = ''.join(traceback.format_exception_only(type(exc), exc)).strip()
            self.messages.put(('error', f'產生報告時發生錯誤：{details}\n請確認 CSV 欄位格式與檔案內容。'))
        finally:
            if temp_path:
                try: temp_path.unlink(missing_ok=True)
                except Exception: pass


if __name__ == '__main__':
    ReportApp().mainloop()
