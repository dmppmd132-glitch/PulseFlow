$ErrorActionPreference = 'Stop'
$Project = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Project

Write-Host '[1/5] 清理舊版 build / dist / spec 暫存資料夾...'
foreach ($dir in @('build', 'dist', '__pycache__')) {
    if (Test-Path $dir) { Remove-Item $dir -Recurse -Force }
}

Write-Host '[2/5] 確認圖示檔案...'
Get-Item .\app_icon.ico, .\app_icon.png | Format-Table Name, Length, LastWriteTime

Write-Host '[3/5] 安裝／更新 PyInstaller...'
python -m pip install --upgrade pyinstaller

Write-Host '[4/5] 重新打包...'
python -m PyInstaller --noconfirm --clean .\PulseFlow.spec

Write-Host '[5/5] 檢查新 EXE...'
Get-Item .\dist\PulseFlow.exe | Format-Table Name, Length, LastWriteTime
Write-Host ''
Write-Host '請執行：.\dist\PulseFlow.exe'
Write-Host '若檔案總管仍顯示舊圖示，請重新啟動 Windows Explorer。'
