$ErrorActionPreference = 'Stop'
$Project = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Project

py -3 -m pip install --upgrade pip
py -3 -m pip install matplotlib openpyxl pillow pyinstaller

if (Test-Path dist) { Remove-Item dist -Recurse -Force }
if (Test-Path build) { Remove-Item build -Recurse -Force }
py -3 -m PyInstaller --noconfirm --clean PulseFlow.spec

$release = Join-Path $Project 'release'
if (Test-Path $release) { Remove-Item $release -Recurse -Force }
New-Item -ItemType Directory -Path $release | Out-Null
Copy-Item (Join-Path $Project 'dist\PulseFlow.exe') $release
Copy-Item (Join-Path $Project 'README_EXE.txt') $release
Write-Host "完成：$release\PulseFlow.exe"
