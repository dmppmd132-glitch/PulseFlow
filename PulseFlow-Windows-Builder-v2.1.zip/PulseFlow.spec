# -*- mode: python ; coding: utf-8 -*-
from pathlib import Path
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

project = Path(SPECPATH)
font_file = project / 'NotoSansCJK-Regular.ttc'
icon_file = project / 'app_icon.ico'
icon_png = project / 'app_icon.png'
datas = collect_data_files('matplotlib')
if font_file.exists():
    datas.append((str(font_file), '.'))
if icon_png.exists():
    datas.append((str(icon_png), '.'))
if icon_file.exists():
    datas.append((str(icon_file), '.'))

hiddenimports = collect_submodules('matplotlib') + [
    'PIL._tkinter_finder',
    'PIL.ImageTk',
]

a = Analysis(
    ['production_report_app.py'],
    pathex=[str(project)],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='PulseFlow',
    icon=str(icon_file) if icon_file.exists() else None,
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
)
